                 MODIFICHE DEL PROGETTO
				 
				 Iscritto: � una classe che tiene traccia delle informazioni relative ai client partecipanti alla chat
				 
				 QuizServerImpl: � una classe che rappresenta il server e implementa l'interfaccia QuizServer      
				                 in cui viene descritto i servizi che offre il server verso i client
				 Modifiche:Aggiunte alcune dichiarazione di variabili e clausole try/catch.
				          E' stata cambiata la condizione di un if e modificate la forma di rappresentazione di alcune stringhe
						  Aggiunto un ciclo for nel metodo locale per settare i valori booleani dopo una votazione
						 
			     QuizClientImpl: � una classe che rappresenta il client che partecipa alla chat
				 Modifiche: E' stata modificata la forma di rappresentazione di alcune stringhe.
						  
			    